package Componentes;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author AXELS
 */

/**
 * ColorRenderer
 *
 * Propósito: Clase que representa un renderizador de celdas de tabla personalizado.
 *
 * Descripción:
 * Esta clase extiende la clase DefaultTableCellRenderer y se utiliza como un renderizador de celdas personalizado
 * para aplicar colores de fondo y de primer plano a las celdas de una tabla.
 */
public class ColorRenderer extends DefaultTableCellRenderer{
    /**
 * Método getTableCellRendererComponent
 *
 * Propósito: Obtener el componente de representación de celda con colores de fondo y texto específicos según el valor de la celda.
 *
 * @param table        Tabla en la que se encuentra la celda.
 * @param value        Valor de la celda.
 * @param isSelected  Indica si la celda está seleccionada.
 * @param hasFocus     Indica si la celda tiene el enfoque.
 * @param row          Índice de la fila de la celda.
 * @param column       Índice de la columna de la celda.
 *
 * @return Componente de representación de celda con colores de fondo y texto específicos según el valor de la celda.
 *
 * Descripción:
 * Este método se utiliza para obtener el componente de representación de celda con colores de fondo y texto específicos
 * según el valor de la celda.
 * Recibe varios parámetros: table (tabla en la que se encuentra la celda), value (valor de la celda),
 * isSelected (indica si la celda está seleccionada), hasFocus (indica si la celda tiene el enfoque),
 * row (índice de la fila de la celda) y column (índice de la columna de la celda).
 * Llama al método getTableCellRendererComponent de la clase padre para obtener el componente base.
 * Obtener el valor de la celda y compararlo con diferentes estados.
 * Establece los colores de fondo y texto según el estado de la celda.
 * Retorna el componente modificado con los colores de fondo y texto específicos según el valor de la celda.
 */
    
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        
        // Obtener el valor de la celda
        String estado = (String) value;
        
        // Establecer el color de fondo de la celda según el valor
        if (estado.equals("Disponible")) {
            c.setBackground(Color.GREEN);
            c.setForeground(Color.BLACK);
        } else if (estado.equals("Confirmada")) {
            c.setBackground(Color.RED);
            c.setForeground(Color.WHITE);
        } else if (estado.equals("Confirmar")) {
            c.setBackground(Color.YELLOW);
            c.setForeground(Color.BLACK);
        } else if (estado.equals("Finalizada")) {
            c.setBackground(Color.BLUE);
            c.setForeground(Color.WHITE);
        }else if (estado.equals("Bloqueado")) {
            c.setBackground(Color.BLACK);
            c.setForeground(Color.WHITE);
        }else if (estado.equals("Durante")) {
            c.setBackground(Color.ORANGE);
            c.setForeground(Color.BLACK);
        }
        
        
        return c;
    }
}
    

