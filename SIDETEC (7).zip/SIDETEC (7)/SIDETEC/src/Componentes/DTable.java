package Componentes;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tzihual
 */

/**
 * DTable
 *
 * Propósito: Clase que representa un renderizador de celdas de tabla personalizado.
 *
 * Descripción:
 * Esta clase extiende la clase DefaultTableCellRenderer y se utiliza como un renderizador de celdas personalizado
 * para aplicar colores de fondo y de primer plano a las celdas de una tabla.
 */

public class DTable extends DefaultTableCellRenderer{
     Color background;
Color foreground;


/**
 * Constructor DTable
 *
 * Propósito: Crear una instancia de la clase DTable con los colores de fondo y texto especificados.
 *
 * @param background Color de fondo de la celda.
 * @param foreground Color de texto de la celda.
 */
public DTable (Color background,Color foreground) {
super();
this.background = background;
this.foreground = foreground;
}


/**
 * Método getTableCellRendererComponent
 *
 * Propósito: Obtener el componente de representación de celda con los colores de fondo y texto especificados.
 *
 * @param table        Tabla en la que se encuentra la celda.
 * @param value        Valor de la celda.
 * @param isSelected  Indica si la celda está seleccionada.
 * @param hasFocus     Indica si la celda tiene el enfoque.
 * @param row          Índice de la fila de la celda.
 * @param column       Índice de la columna de la celda.
 *
 * @return Componente de representación de celda con los colores de fondo y texto especificados.
 *
 * Descripción:
 * Este método se utiliza para obtener el componente de representación de celda con los colores de fondo y texto especificados.
 * Recibe varios parámetros: table (tabla en la que se encuentra la celda), value (valor de la celda),
 * isSelected (indica si la celda está seleccionada), hasFocus (indica si la celda tiene el enfoque),
 * row (índice de la fila de la celda) y column (índice de la columna de la celda).
 * Llama al método getTableCellRendererComponent de la clase padre para obtener el componente base.
 * Establece los colores de fondo y texto en el componente base.
 * Retorna el componente modificado con los colores especificados.
 */
public Component getTableCellRendererComponent(JTable table, Object value,boolean isSelected, boolean hasFocus, int row, int column) {
Component comp = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
comp.setBackground(background);
comp.setForeground(foreground);
return comp;
}
}
