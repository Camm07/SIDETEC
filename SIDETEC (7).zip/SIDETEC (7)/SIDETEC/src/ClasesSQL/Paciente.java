package ClasesSQL;

import static Conexión.Conexión.getConnection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Paciente {
    private int id;
    private String nombre;
    private String apellido;
    private int edad;
    private String genero;
    private String telefono;
    private String direccion;

    public Paciente() {
    }
<<<<<<< OURS
/**
 * Constructor de la clase Paciente.
 *
 * @param id        El ID del paciente.
 * @param nombre    El nombre del paciente.
 * @param apellido  El apellido del paciente.
 * @param edad      La edad del paciente.
 * @param genero    El género del paciente.
 * @param telefono  El número de teléfono del paciente.
 * @param direccion La dirección del paciente.
 *
 * Propósito:
 * Inicializar los atributos de la clase Paciente con los valores proporcionados.
 * 
 * Descripción:
 * Este constructor se utiliza para crear un objeto Paciente con los datos proporcionados.
 * Asigna los valores de los parámetros a los correspondientes atributos de la clase Paciente.
 */

    public Paciente(int id, String nombre, String apellido, int edad, String genero, String telefono,
            String direccion) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.genero = genero;
        this.telefono = telefono;
        this.direccion = direccion;
    }

/**
 * Obtiene el ID del paciente.
 *
 * @return El ID del paciente.
 *
 * Propósito:
 * Obtener el ID del paciente.
 * 
 * Descripción:
 * Este método devuelve el valor del atributo "id" que representa el ID del paciente.
 */
    public int getId() {
        return id;
    }

       
    
 /**
 * Establece el ID del paciente.
 *
 * @param id El nuevo ID del paciente.
 *
 * Propósito:
 * Establecer el ID del paciente.
 * 
 * Descripción:
 * Este método asigna un nuevo valor al atributo "id" que representa el ID del paciente.
 */
    public void setId(int id) {
        this.id = id;
    }

 /**
 * Obtiene el nombre del paciente.
 *
 * @return El nombre del paciente.
 *
 * Propósito:
 * Obtener el nombre del paciente.
 * 
 * Descripción:
 * Este método devuelve el valor del atributo "nombre" que representa el nombre del paciente.
 */
    
    public String getNombre() {
        return nombre;
    }

 
/**
 * Establece el nombre del paciente.
 *
 * @param nombre El nombre del paciente.
 *
 * Propósito:
 * Establecer el nombre del paciente.
 * 
 * Descripción:
 * Este método asigna el valor del parámetro "nombre" al atributo "nombre" del paciente.
 */
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    
/**
 * Obtener el apellido del paciente.
 *
 * @return El apellido del paciente.
 *
 * Propósito:
 * Obtener el apellido del paciente.
 * 
 * Descripción:
 * Este método devuelve el valor del atributo "apellido" del paciente.
 */
    public String getApellido() {
        return apellido;
    }

    
/**
 * Establecer el apellido del paciente.
 *
 * @param apellido El apellido del paciente.
 *
 * Propósito:
 * Establecer el apellido del paciente.
 * 
 * Descripción:
 * Este método establece el valor del atributo "apellido" del paciente con el valor proporcionado como argumento.
 */
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    
/**
 * Obtener la edad del paciente.
 *
 * @return La edad del paciente.
 *
 * Propósito:
 * Obtener la edad del paciente.
 * 
 * Descripción:
 * Este método devuelve el valor del atributo "edad" del paciente.
 */
    public int getEdad() {
        return edad;
    }

 /**
 * Establecer la edad del paciente.
 *
 * @param edad La nueva edad del paciente.
 *
 * Propósito:
 * Establecer la edad del paciente.
 * 
 * Descripción:
 * Este método establece el valor del atributo "edad" del paciente con el valor proporcionado.
 * 
 * Argumentos:
 * - edad (int): La nueva edad del paciente.
 * 
 * Respuesta:
 * Ninguna.
 */
    
    public void setEdad(int edad) {
        this.edad = edad;
    }

    
/**
 * Obtener el género del paciente.
 *
 * @return El género del paciente.
 *
 * Propósito:
 * Obtener el género del paciente.
 * 
 * Descripción:
 * Este método devuelve el valor del atributo "genero" del paciente.
 * 
 * Respuesta:
 * El género del paciente (String).
 */
    public String getGenero() {
        return genero;
    }

    
/**
 * Establecer el género del paciente.
 *
 * @param genero El género del paciente.
 *
 * Propósito:
 * Establecer el género del paciente.
 * 
 * Descripción:
 * Este método establece el valor del atributo "genero" del paciente.
 * 
 * Argumentos:
 * genero (String): El género del paciente.
 *
 * Respuesta: Ninguna.
 */
    public void setGenero(String genero) {
        this.genero = genero;
    }
    
   /**
 * Obtener el número de teléfono del paciente.
 *
 * @return El número de teléfono del paciente.
 *
 * Propósito:
 * Obtener el número de teléfono del paciente.
 *
 * Descripción:
 * Este método devuelve el valor del atributo "telefono" del paciente, que representa su número de teléfono.
 *
 * Respuesta:
 * String: El número de teléfono del paciente.
 */
    public String getTelefono() {
        return telefono;
    }

/**
 * Establecer el número de teléfono del paciente.
 *
 * @param telefono El número de teléfono a establecer.
 *
 * Propósito:
 * Establecer el número de teléfono del paciente.
 *
 * Descripción:
 * Este método establece el valor del atributo "telefono" del paciente con el número de teléfono especificado.
 *
 * Argumentos:
 * telefono (String): El número de teléfono a establecer para el paciente.
 *
 * Respuesta: Ninguna.
 */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

/**
 * Obtener la dirección del paciente.
 *
 * @return La dirección del paciente.
 *
 * Propósito:
 * Obtener la dirección del paciente.
 *
 * Descripción:
 * Este método devuelve el valor del atributo "direccion" que representa la dirección del paciente.
 *
 * @return (String) La dirección del paciente.
 */
    public String getDireccion() {
        return direccion;
    }

/**
 * Establecer la dirección del paciente.
 *
 * @param direccion La nueva dirección del paciente.
 *
 * Propósito:
 * Establecer la dirección del paciente.
 *
 * Descripción:
 * Este método establece el valor del atributo "direccion" que representa la dirección del paciente, con el valor proporcionado como argumento.
 *
 * @param direccion (String) La nueva dirección del paciente.
 */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    
/**
 * Consultar un paciente por su ID.
 *
 * @param id El ID del paciente a consultar.
 * @return El objeto Paciente correspondiente al ID proporcionado, o null si no se encuentra ningún paciente con ese ID.
 *
 * Propósito:
 * Consultar un paciente por su ID.
 *
 * Descripción:
 * Este método consulta un paciente en la base de datos utilizando su ID como criterio de búsqueda.
 * Retorna un objeto Paciente que contiene los datos del paciente encontrado, o null si no se encuentra ningún paciente con ese ID.
 *
 * @param id (int) El ID del paciente a consultar.
 * @return (Paciente) El objeto Paciente correspondiente al ID proporcionado, o null si no se encuentra ningún paciente con ese ID.
 */
    public static Paciente consultar(int id) {
        try {
            ResultSet row = getConnection()
                    .prepareStatement(
                            String.format(
                                    "Select * from pacientes where id like %d;",
                                    id))
                    .executeQuery();
            while (row.next()) {
                int index = 1;
                return new Paciente(row.getInt(index++),
                        row.getString(index++),
                        row.getString(index++),
                        row.getInt(index++),
                        row.getString(index++),
                        row.getString(index++),
                        row.getString(index++));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    
/**
 * Consultar un paciente por su número de teléfono.
 *
 * @param telefono El número de teléfono del paciente a consultar.
 * @return El objeto Paciente correspondiente al número de teléfono proporcionado, o null si no se encuentra ningún paciente con ese número de teléfono.
 *
 * Propósito:
 * Consultar un paciente por su número de teléfono.
 *
 * Descripción:
 * Este método consulta un paciente en la base de datos utilizando su número de teléfono como criterio de búsqueda.
 * Retorna un objeto Paciente que contiene los datos del paciente encontrado, o null si no se encuentra ningún paciente con ese número de teléfono.
 *
 * @param telefono (String) El número de teléfono del paciente a consultar.
 * @return (Paciente) El objeto Paciente correspondiente al número de teléfono proporcionado, o null si no se encuentra ningún paciente con ese número de teléfono.
 */
=======

    public Paciente(int id, String nombre, String apellido, int edad, String genero, String telefono,
            String direccion) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.genero = genero;
        this.telefono = telefono;
        this.direccion = direccion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public static Paciente consultar(int id) {
        try {
            ResultSet row = getConnection()
                    .prepareStatement(
                            String.format(
                                    "Select * from pacientes where id like %d;",
                                    id))
                    .executeQuery();
            while (row.next()) {
                int index = 1;
                return new Paciente(row.getInt(index++),
                        row.getString(index++),
                        row.getString(index++),
                        row.getInt(index++),
                        row.getString(index++),
                        row.getString(index++),
                        row.getString(index++));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

>>>>>>> THEIRS
    public static Paciente consultar(String telefono) {
        try {
            String a;
            ResultSet row = getConnection().prepareStatement(a = String.format("Select * from pacientes where telefono like '%s';",
                                    telefono))
                    .executeQuery();
            System.out.println(a);
            while (row.next()) {
                int index = 1;
                return new Paciente(row.getInt(index++),
                        row.getString(index++),
                        row.getString(index++),
                        row.getInt(index++),
                        row.getString(index++),
                        row.getString(index++),
                        row.getString(index++));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
