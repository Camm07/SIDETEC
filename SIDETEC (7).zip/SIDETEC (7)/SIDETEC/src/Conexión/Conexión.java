package Conexión;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.TimeZone;

import static javax.swing.JOptionPane.showMessageDialog;

/**
 * Conexión
 *
 * Propósito: Clase para establecer la conexión con la base de datos.
 *
 * Descripción:
 * Esta clase proporciona un método estático para obtener una conexión a la base de datos utilizando JDBC.
 */
public class Conexión{
    private static Connection con;
    
 /**
 * Método getConnection
 *
 * Propósito: Obtener una instancia de conexión a la base de datos.
 *
 * @return Instancia de conexión a la base de datos.
 *
 * Descripción:
 * Este método se utiliza para obtener una instancia de conexión a la base de datos.
 * Si ya existe una instancia de conexión, se retorna esa instancia en lugar de crear una nueva.
 * Si no hay una instancia de conexión existente, se intenta establecer la conexión con la base de datos.
 * Se especifica la URL de la base de datos, el usuario y la contraseña para la conexión.
 * También se establece la zona horaria predeterminada para la conexión.
 * Si la conexión se establece correctamente, se imprime un mensaje de éxito y se retorna la instancia de conexión.
 * Si ocurre un error durante la conexión, se muestra un mensaje de error.
 * Si no se puede establecer la conexión, se retorna null.
 */
    
    public static Connection getConnection() {
        if (con!=null)
            return con;
        try {
            String db = "jdbc:mysql://localhost:3306/consultorio_dental?serverTimezone=America/Los_Angeles";
            TimeZone timeZone = TimeZone.getTimeZone("UTC-07:00");
            TimeZone.setDefault(timeZone);
             con = DriverManager.getConnection(db, "root", "admi1");
            con.prepareStatement("SET GLOBAL time_zone = '-07:00';").executeQuery();
            System.out.println("CONECTADO");
            return con;
        } catch (SQLException e) {
            showMessageDialog(null, "Error en la conexion. " + e.getMessage());
        }
        return null;
    }
}
